#include <conio.h>
#include <graphics.h>

main()
{
	int gd = DETECT, gm;
	char pathtodriver[] = "";
	initgraph(&gd, &gm, pathtodriver);
	
	circle(getmaxx()/2,getmaxy()/2,10);
	
	getch();
	closegraph();
}

